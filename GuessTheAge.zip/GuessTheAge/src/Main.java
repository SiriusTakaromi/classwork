import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.print("Enter your age: ");
        int age = scr.nextInt();
        Random rnd = new Random();
        int age1 = rnd.nextInt(120);
        System.out.println("I guess you age... ");
        System.out.println("I'm still thinking... ");
        System.out.println("Are you " + age1 + " years old?");

        if (age == age1) {
            System.out.println("Yes! I wrote " + age + "!");
            System.out.println("Incredible! I guessed your age! :0");

        } else {
            System.out.println("No! I wrote " + age + "!");
            System.out.println("Oh NO! I couldn't guess your age! :( ");

        }

        System.out.println("I was wrong by " + Math.abs(age1 - age) + " years!");

        System.out.print("At one time press 'Shift+F10' to start again!");
        System.out.println(" ");








    }

}





