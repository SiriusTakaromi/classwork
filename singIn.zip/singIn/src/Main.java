import java.util.Scanner;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        int takaromi;

        Scanner scr = new Scanner(System.in);
        System.out.print("Enter your login: ");
        String login = scr.nextLine();



        System.out.print("Enter your password: ");
        String pass = scr.nextLine();

        Random rnd = new Random();
        long ID = rnd.nextLong(Long.MAX_VALUE);
        System.out.printf("Registered user with login: %s, password: %s, identification %d", login, pass, ID);




        System.out.println(" ");
        System.out.println("Welcome to SOLO " + login + "!");
        System.out.println("Your personal ID: " + ID + "!");
    }
}